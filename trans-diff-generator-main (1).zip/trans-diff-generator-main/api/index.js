const express = require("express");
const path = require("path");
const { execute } = require("../_custom.js");

// let flag = {};
const app = express();

app.get("/", function (req, res) {
  res.sendFile(path.join(__dirname, "..", "html", "index.html"));
});

// console.info("flag.inProgress", flag.inProgress);

app.get("/send", async (req, res) => {
  // if (flag.inProgress) {
  //   res.status(200).json({
  //     message: "Already Inprogress",
  //   });
  //   return;
  // }
  execute();
  res.status(200).json({
    message: "Data received successfully",
  });
});

// app.listen(3000, () => console.log("Server ready on port 3000."));

module.exports = app;
